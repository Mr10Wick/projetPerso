<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* accueil.html.twig */
class __TwigTemplate_1aaec0925108c34e5a47b18f89b67deb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "accueil.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "accueil.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"fr\">
<link rel=\"stylesheet\" href=\"/css/style.css\">

<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Formulaire de Contact</title>
</head>

<body>
    <div>
        <h1><img src=\"/css/logo.png\" alt=\"Logo entreprise\" class=\"logo\"></h1>
    </div> 
    <div class=\"box\">
        <h2 style=\"font-family: Phosphate;\">Contactez-nous</h2>
        <form method=\"post\" action=\"/contact\">
            <div class=\"form-group\">
                <input type=\"text\" name=\"name\" placeholder=\"Nom*\" class=\"name\" required>
            </div>
            <div class=\"form-group\">
                <input type=\"email\" name=\"email\" placeholder=\"Email\" class=\"email\">
            </div>
            
            <div class=\"form-group\">
                <input type=\"submit\" value=\"Envoyer\" class=\"btn\">
            </div>
        </form>
    </div>
    
</body>

</html>

";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "accueil.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"fr\">
<link rel=\"stylesheet\" href=\"/css/style.css\">

<head>
    <meta charset=\"UTF-8\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
    <title>Formulaire de Contact</title>
</head>

<body>
    <div>
        <h1><img src=\"/css/logo.png\" alt=\"Logo entreprise\" class=\"logo\"></h1>
    </div> 
    <div class=\"box\">
        <h2 style=\"font-family: Phosphate;\">Contactez-nous</h2>
        <form method=\"post\" action=\"/contact\">
            <div class=\"form-group\">
                <input type=\"text\" name=\"name\" placeholder=\"Nom*\" class=\"name\" required>
            </div>
            <div class=\"form-group\">
                <input type=\"email\" name=\"email\" placeholder=\"Email\" class=\"email\">
            </div>
            
            <div class=\"form-group\">
                <input type=\"submit\" value=\"Envoyer\" class=\"btn\">
            </div>
        </form>
    </div>
    
</body>

</html>

", "accueil.html.twig", "/Applications/MAMP/htdocs/MonProjet/templates/accueil.html.twig");
    }
}
